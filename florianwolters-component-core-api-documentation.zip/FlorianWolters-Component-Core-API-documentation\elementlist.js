
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Core\\DebugPrintInterface"],["c","FlorianWolters\\Component\\Core\\DebugPrintTrait"]];
